//
//  myLabel.m
//  HelloLoneTerm
//
//  Created by Jenny on 2015/11/16.
//  Copyright © 2015年 PatrickCheng. All rights reserved.
//

#import "myLabel.h"

@implementation myLabel


-(void)awakeFromNib{
    NSLog(@"create label");
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
