//
//  MyDelegate.m
//  HelloLoneTerm
//
//  Created by Jenny on 2015/11/16.
//  Copyright © 2015年 PatrickCheng. All rights reserved.
//

#import "MyDelegate.h"

@implementation MyDelegate

@end
