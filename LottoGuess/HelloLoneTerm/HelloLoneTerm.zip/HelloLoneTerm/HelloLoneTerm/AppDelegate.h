//
//  AppDelegate.h
//  HelloLoneTerm
//
//  Created by Jenny on 2015/11/16.
//  Copyright © 2015年 PatrickCheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

